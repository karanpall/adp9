package graphDykstra;

import java.util.ArrayList;
import java.util.List;

public class Knoten<E>
{
    private E elem;
    private List<Knoten<E>> neighbors = new ArrayList<Knoten<E>>();
    private List<Integer> costs = new ArrayList<Integer>();

    Knoten(E elem)
    {
        this.elem = elem;
    }

    public E getElem()
    {
        return elem;
    }

    public void addNeighbor(Knoten<E> neighbor, int cost)
    {
        neighbors.add(neighbor);
        int index = neighbors.indexOf(neighbor);
        costs.add(index, cost);
    }

    public void removeNeighbor(Knoten<E> neighbor)
    {
        int index = neighbors.indexOf(neighbor);
        if (index != -1)
        {
            neighbors.remove(index);
            costs.remove(index);
        }
    }

    public List<Knoten<E>> getNeighbors()
    {
        return neighbors;
    }

    public List<Integer> getCosts()
    {
        return costs;
    }

  

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
        {
            return true;
        }
        if (obj == null)
        {
            return false;
        }
        if (getClass() != obj.getClass())
        {
            return false;
        }
        Knoten other = (Knoten) obj;
        if (elem == null)
        {
            if (other.elem != null)
            {
                return false;
            }
        }
        else if (!elem.equals(other.elem))
        {
            return false;
        }
        return true;
    }

//    @Override
//    public String toString()
//    {
//        return String.format("[<Vertex> elem=%s]", elem);
//    }
}
