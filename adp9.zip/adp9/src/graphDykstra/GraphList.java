package graphDykstra;

import java.util.ArrayList;
import java.util.List;

public class GraphList<E> implements IGraph<E>
{

    private List<Knoten<E>> list = new ArrayList<Knoten<E>>();

    @Override
    public void insert(E elem)
    {
        Knoten<E> vertex = new Knoten<E>(elem);
        list.add(vertex);
    }

    @Override
    public E remove(E elem)
    {
        Knoten<E> vertex = new Knoten<E>(elem);
        int index = list.indexOf(vertex);

        if (index != -1)
        {
            vertex = list.remove(index);
            for (int i = 0; i < list.size(); i++)
            {
                list.get(i).removeNeighbor(vertex);
            }
        }
        return vertex.getElem();
    }

    @Override
    public void addLink(E from, E to, int costs)
    {
        Knoten<E> vertexFrom = new Knoten<E>(from);
        int indexFrom = list.indexOf(vertexFrom);
        if (indexFrom == -1)
        {
            list.add(vertexFrom);
            indexFrom = list.indexOf(vertexFrom);
        }
        else
        {
            vertexFrom = list.get(indexFrom);
        }
        Knoten<E> vertexTo = new Knoten<E>(to);
        int indexTo = list.indexOf(vertexTo);
        if (indexTo == -1)
        {
            list.add(vertexTo);
            indexFrom = list.indexOf(vertexTo);
        }
        else
        {
            vertexTo = list.get(indexTo);
        }
        vertexFrom.addNeighbor(vertexTo, costs);
        vertexTo.addNeighbor(vertexFrom, costs);
    }

    @Override
    public List<Knoten<E>> getNeighbours(E elem)
    {
        List<Knoten<E>> neighbourList = null;
        Knoten<E> vertex = new Knoten<E>(elem);
        int index = list.indexOf(vertex);
        if (index != -1)
        {
            neighbourList = list.get(index).getNeighbors();
        }
        return neighbourList;
    }

    @Override
    public List<Knoten<E>> getKnoten()
    {
        return list;
    }

//    @Override
//    public void printAll()
//    {
//        System.out.println(list.toString());
//    }

    @Override
    public int getCost(E from, E to)
    {
        int cost = -1;
        Knoten<E> vertexFrom = new Knoten<E>(from);
        int indexFrom = list.indexOf(vertexFrom);
        if (indexFrom != -1)
        {
            Knoten<E> vertexTo = new Knoten<E>(to);
            int indexTo = list.get(indexFrom).getNeighbors().indexOf(vertexTo);
            if (indexTo != -1)
            {
                cost = list.get(indexFrom).getCosts().get(indexTo);
            }
        }
        return cost;
    }

}
