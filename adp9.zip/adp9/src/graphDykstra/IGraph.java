package graphDykstra;

import java.util.List;

public interface IGraph<E> {

    void insert(E elem);
    
    E remove(E elem);
    
    void addLink(E von, E nach, int costs);
    
    List<Knoten<E>> getNeighbours(E elem);
    
    public int getCost(E von, E nach);
    
    List<Knoten<E>> getKnoten();
    
    //void printAll();
}
