package graphDykstra;

import java.util.List;

public interface IGraph<E> {

    void insert(E elem);
    
    E remove(E elem);
    
    void addLink(E from, E to, int costs);
    
    List<Knoten<E>> getNeighbours(E elem);
    
    public int getCost(E from, E to);
    
    List<Knoten<E>> getKnoten();
    
    //void printAll();
}
