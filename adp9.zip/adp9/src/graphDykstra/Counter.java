package graphDykstra;

public class Counter
{

    int counter;

    public int getCounter()
    {
        return counter;
    }

    public void setCounter(int counter)
    {
        this.counter = counter;
    }
    
    public void countOne(){
         this.counter ++;
    }
    
    
    
}
