package graphDykstra;

import java.util.ArrayList;
import java.util.List;

public class Dykstra<E> 
{

    IGraph<E> graph;
    List<DykstraKnoten<E>> markedList;
    E start = null;
    int dykstraCounter;
    boolean COUNTERFLAG = false;
    public Counter counter;

    
    public void dykstraAlgorithm(IGraph<E> graph, E start, boolean COUNTERFLAG)
    {

        counter = new Counter();
        counter.setCounter(0);
        this.graph = graph;
        this.start = start;
        markedList = new ArrayList<DykstraKnoten<E>>();
        List<DykstraKnoten<E>> notMarkedList = new ArrayList<DykstraKnoten<E>>();

        DykstraKnoten<E> nextVertexWrapper = new DykstraKnoten<E>(new Knoten<E>(start));
        nextVertexWrapper.setCosts(0);
        nextVertexWrapper.setMarked(true);
        nextVertexWrapper.setRelated(nextVertexWrapper);
        markedList.add(nextVertexWrapper);

        E next = start;
        DykstraKnoten<E> vW;
        List<Knoten<E>> neighnourList = graph.getNeighbours(next);
        int costs;
        int indexLowestCosts;
        int lowestCosts;

        do
        {
            if (COUNTERFLAG)
            {
                counter.countOne();
            }
            for (Knoten<E> elem : neighnourList)
            {
                if (elem != null)
                {
                    vW = new DykstraKnoten<E>(elem);
                    if (markedList.indexOf(vW) == -1 && notMarkedList.indexOf(vW) == -1)
                    {
                        notMarkedList.add(vW);
                    }
                }
                if (COUNTERFLAG)
                {
                    counter.countOne();
                }
            }

            for (DykstraKnoten<E> elem : notMarkedList)
            {
                E to = elem.getOwnVertex().getElem();
                costs = graph.getCost(nextVertexWrapper.getOwnVertex().getElem(), to);

                if (costs > -1)
                {
                    costs += nextVertexWrapper.getCosts();
                    if (costs < elem.getCosts())
                    {
                        elem.setCosts(costs);
                        elem.setRelated(nextVertexWrapper);
                    }
                }
                if (COUNTERFLAG)
                {
                    counter.countOne();
                }
            }

            lowestCosts = Integer.MAX_VALUE;
            indexLowestCosts = -1;
            for (int i = 0; i < notMarkedList.size(); i++)
            {
                costs = notMarkedList.get(i).getCosts();
                if (costs < lowestCosts)
                {
                    indexLowestCosts = i;
                    lowestCosts = costs;
                }
                if (COUNTERFLAG)
                {
                    counter.countOne();
                }
            }

            if (indexLowestCosts > -1)
            {
                nextVertexWrapper = notMarkedList.remove(indexLowestCosts);
                nextVertexWrapper.setMarked(true);
                markedList.add(nextVertexWrapper);
                neighnourList = graph.getNeighbours(nextVertexWrapper.getOwnVertex().getElem());
            }
            if (COUNTERFLAG)
            {
                counter.countOne();
            }
        } while (notMarkedList.size() > 0);

    }

    public int getCounter()
    {
        return counter.getCounter();
    }

 

    /*
     * (non-Javadoc)
     * 
     * @see graphDykstra.IDykstra#printDykstra()
     */
//    @Override
//    public void printDykstra()
//    {
//        StringBuilder sB = new StringBuilder();
//
//        sB.append("[StartElement: ");
//        sB.append(start);
//        sB.append(" Dykstra:( ");
//        for (int i = 0; i < markedList.size(); i++)
//        {
//            sB.append(markedList.get(i));
//            if ((i + 1) < markedList.size())
//            {
//                sB.append(", ");
//            }
//        }
//        sB.append(")]");
//        System.out.println(sB.toString());
//    }
}
