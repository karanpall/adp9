package graphDykstra;

import java.util.ArrayList;
import java.util.List;

public class GraphMatrix<E> implements IGraph<E>
{
    int[][] matrix;
    List<Knoten<E>> vertexList = new ArrayList<Knoten<E>>();

    GraphMatrix(int n)
    {
        matrix = new int[n][n];
    }

    @Override
    public void insert(E elem)
    {
        Knoten<E> vertex = new Knoten<E>(elem);
        vertexList.add(vertex);
    }

    @Override
    public E remove(E elem)
    {
        Knoten<E> vertex = new Knoten<E>(elem);
        int index = vertexList.indexOf(vertex);
        vertex = vertexList.remove(index);

        for (int i = 0; i < matrix.length && index > -1; i++)
        {
            matrix[index][i] = 0;
            matrix[i][index] = 0;
        }

        return vertex.getElem();
    }

    @Override
    public void addLink(E from, E to, int costs)
    {
        Knoten<E> vertexFrom = new Knoten<E>(from);
        int indexFrom = vertexList.indexOf(vertexFrom);
        if (indexFrom == -1)
        {
            vertexList.add(vertexFrom);
            indexFrom = vertexList.indexOf(vertexFrom);
        }

        Knoten<E> vertexTo = new Knoten<E>(to);
        int indexTo = vertexList.indexOf(vertexTo);
        if (indexTo == -1)
        {
            vertexList.add(vertexTo);
            indexTo = vertexList.indexOf(vertexTo);
        }

        matrix[indexFrom][indexTo] = costs;
        matrix[indexTo][indexFrom] = costs;
    }

    @Override
    public List<Knoten<E>> getNeighbours(E elem)
    {
        List<Knoten<E>> neighbourList = new ArrayList<Knoten<E>>();
        Knoten<E> vertex = new Knoten<E>(elem);
        int index = vertexList.indexOf(vertex);

        if (index != -1)
        {
            for (int i = 0; i < matrix[index].length; i++)
            {
                if (matrix[index][i] != 0)
                {
                    neighbourList.add(vertexList.get(i));
                }
            }
        }
        return neighbourList;
    }

    @Override
    public int getCost(E from, E to)
    {
        Knoten<E> vertexFrom = new Knoten<E>(from);
        int indexFrom = vertexList.indexOf(vertexFrom);
        if (indexFrom == -1)
        {
            return -1;
        }
        Knoten<E> vertexTo = new Knoten<E>(to);
        int indexTo = vertexList.indexOf(vertexTo);
        if (indexTo == -1)
        {
            return -1;
        }

        int cost = matrix[indexFrom][indexTo];
        if (cost == 0)
        {
            return -1;
        }
        return cost;
    }

    @Override
    public List<Knoten<E>> getKnoten()
    {
        return vertexList;
    }

//    @Override
//    public void printAll()
//    {
//        System.out.println(vertexList.toString());
//    }
}
