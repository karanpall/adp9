package graphDykstra;

import java.util.ArrayList;

public class TestFrame
{

    public static void main(String[] args)
    {

                IGraph<Integer> graph = new GraphMatrix<Integer>(22);
                
                graph.addLink(new Integer(1), new Integer(2), 1);
                graph.addLink(new Integer(1), new Integer(3), 2);
                graph.addLink(new Integer(1), new Integer(4), 5);
                graph.addLink(new Integer(1), new Integer(5), 4);
                graph.addLink(new Integer(1), new Integer(6), 8);
                graph.addLink(new Integer(2), new Integer(3), 7);
                graph.addLink(new Integer(2), new Integer(7), 12);
                graph.addLink(new Integer(3), new Integer(4), 4);
                graph.addLink(new Integer(4), new Integer(5), 10);
                graph.addLink(new Integer(5), new Integer(6), 3);
                graph.addLink(new Integer(6), new Integer(7), 4);
                
//                graph.printAll();
                
                Dykstra<Integer> dyk = new Dykstra<Integer>();
                dyk.dykstraAlgorithm(graph, new Integer(1),true);
//                dyk.printDykstra();
                
                dyk.dykstraAlgorithm(graph, new Integer(4),true);
//                dyk.printDykstra();

//        IGraph<String> graph = new GraphMatrix<String>(22);
//        
//        graph.addLink(new String("G"), new String("C"), 1);
//        graph.addLink(new String("G"), new String("B"), 2);
//        graph.addLink(new String("G"), new String("A"), 5);
//        graph.addLink(new String("G"), new String("F"), 4);
//        graph.addLink(new String("G"), new String("E"), 8);
//        graph.addLink(new String("C"), new String("B"), 7);
//        graph.addLink(new String("C"), new String("D"), 12);
//        graph.addLink(new String("B"), new String("A"), 4);
//        graph.addLink(new String("A"), new String("F"), 10);
//        graph.addLink(new String("F"), new String("E"), 3);
//        graph.addLink(new String("E"), new String("D"), 4);
//
//        graph.printAll();
//
//        Dykstra<String> dyk = new Dykstra<String>();
//        dyk.doDykstraWithFixedStart(graph, new String("G"));
//        dyk.printDykstra();
//
////        dyk.doDykstraWithFixedStart(graph, new String(4));
////        dyk.printDykstra();

    }

}
