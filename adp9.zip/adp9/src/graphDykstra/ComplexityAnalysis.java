package graphDykstra;

public class ComplexityAnalysis
{

    private static boolean COUNTERFLAG = true;

    public static void main(String[] args)
    {

        testMatrix();
        testList();

    }

    private static void testMatrix()
    {
        GraphMatrix<Integer> graph;
        Dykstra<Integer> dyk;

        int n;

        // nur bis k^4, aber k^5 out of memory
        for (int i = 1; i <= 3; i++)
        {

            n = (int) Math.pow(10, i);
            graph = new GraphMatrix<Integer>(n);

            createGraph(graph, n);
            System.out.println(i);
//            graph.printAll();

            dyk = new Dykstra<Integer>();
            dyk.dykstraAlgorithm(graph, new Integer(1), COUNTERFLAG);
            System.out.println("Aufwand mit Adjazenzmatrix bei n = " + n + " ist : " + dyk.getCounter());

            //dyk.printDykstra();
        }
        
    }

    private static void testList()
    {
        GraphList<Integer> graph;
        Dykstra<Integer> dyk;
        Counter counter = new Counter();
        int n;

        // nur bis k^4, aber k^5 out of memory
        for (int i = 1; i <= 3; i++)
        {
            n = (int) Math.pow(10, i);
            graph = new GraphList<Integer>();
            createGraph(graph, n);

//            graph.printAll();

            dyk = new Dykstra<Integer>();
            dyk.dykstraAlgorithm(graph, new Integer(1), COUNTERFLAG);
            System.out.println("Aufwand mit Adjazenzliste bei n = " + n + " ist : " + dyk.getCounter());
        }
    }

    private static void createGraph(IGraph<Integer> graph, int n)
    {
        int[][] matrix = new int[n][n];
        int cost;

        for (int i = 0; i < n; i++)
        {
            graph.insert(new Integer(i));

        }

        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < i; j++)
            {

                matrix[i][j] = (int) (Math.random() * 2);
                cost = matrix[i][j];
                matrix[j][i] = matrix[i][j];
                graph.addLink(new Integer(i), new Integer(j), matrix[i][j]);
            }
        }
    }

}
